# Roll Call — live attendance with zone alerts

1. Push the CONTENTS of this folder (index.html, track.html, api/, package.json) to the root of a GitHub repo.
2. vercel.com → Add New → Project → import the repo → Deploy.
3. In the project: Storage → add **Upstash Redis** (Marketplace). It adds the database variables automatically.
4. Settings → Environment Variables → add `ADMIN_PIN` (your head PIN). Optional: `TZ_NAME` (default Asia/Kolkata).
5. Redeploy. Open your site, enter the PIN, set the zone, add people, and use "Copy link" to send each person their personal tracking link.

Staff open their link on their phone, tap "Start sharing my location", and keep the page open.
