const U=process.env.UPSTASH_REDIS_REST_URL||process.env.KV_REST_API_URL,T=process.env.UPSTASH_REDIS_REST_TOKEN||process.env.KV_REST_API_TOKEN;
const call=async a=>(await fetch(U,{method:'POST',headers:{Authorization:'Bearer '+T},body:JSON.stringify(a)})).json();
const day=()=>new Date().toLocaleDateString('en-CA',{timeZone:process.env.TZ_NAME||'Asia/Kolkata'});
exports.load=async()=>{
  const r=await call(['GET','rollcall']);
  const s=r.result?JSON.parse(r.result):{zone:{name:'Main campus',lat:null,lng:null,r:100,cut:'09:30'},people:[],alerts:[]};
  if(s.day!==day()){s.day=day();s.alerts=[];s.people.forEach(p=>{p.st='absent';p.at=null;p.seen=null;p.d=null;p.mark=null})}
  return s};
exports.save=s=>call(['SET','rollcall',JSON.stringify(s)]);
exports.dist=(a,b,c,d)=>{const R=6371000,t=Math.PI/180,x=(c-a)*t,y=(d-b)*t,h=Math.sin(x/2)**2+Math.cos(a*t)*Math.cos(c*t)*Math.sin(y/2)**2;return 2*R*Math.asin(Math.sqrt(h))};
