const {load,save,dist}=require('./_db');
module.exports=async(req,res)=>{
  const b=req.body||{},s=await load(),p=s.people.find(p=>p.id===b.id),z=s.zone;
  if(!p)return res.status(404).json({error:'This link is not valid. Ask your head for a new one.'});
  if(z.lat==null||isNaN(z.lat))return res.status(409).json({error:'The attendance zone is not set yet.'});
  const d=Math.round(dist(z.lat,z.lng,+b.lat,+b.lng)),now=Date.now(),inside=d<=z.r;
  p.d=d;p.seen=now;
  const al=(type,msg)=>s.alerts.push({id:now+p.id,t:now,type,msg});
  if(!(b.acc>Math.max(50,z.r))){
    if(p.st==='absent'&&inside){p.st='in';p.at=now;al('in',p.name+' checked in')}
    else if(p.st==='in'&&!inside){p.st='out';al('out',p.name+' ('+p.role+') left '+z.name+' — now '+d+' m away')}
    else if(p.st==='out'&&inside){p.st='in';al('back',p.name+' is back inside '+z.name)}}
  s.alerts=s.alerts.slice(-80);await save(s);
  res.json({st:p.st,d,r:z.r,name:p.name})};
