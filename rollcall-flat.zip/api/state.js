const {load,save}=require('./_db');
const clean=v=>String(v||'').slice(0,60);
module.exports=async(req,res)=>{
  if(!process.env.ADMIN_PIN||req.headers['x-pin']!==process.env.ADMIN_PIN)return res.status(401).json({error:'Wrong PIN'});
  const s=await load(),b=req.body||{};
  if(req.method==='POST'){
    if(b.act==='add')s.people.push({id:Math.random().toString(36).slice(2,10),name:clean(b.name),phone:clean(b.phone),role:clean(b.role),st:'absent',at:null,seen:null,d:null,mark:null});
    if(b.act==='zone')s.zone={...s.zone,name:clean(b.zone.name),lat:+b.zone.lat,lng:+b.zone.lng,r:+b.zone.r||100,cut:clean(b.zone.cut)||'09:30'};
    if(b.act==='mark'){const p=s.people.find(p=>p.id===b.id);if(p)p.mark=b.mark||null}
    if(b.act==='del')s.people=s.people.filter(p=>p.id!==b.id);
    await save(s)}
  res.json(s)};
